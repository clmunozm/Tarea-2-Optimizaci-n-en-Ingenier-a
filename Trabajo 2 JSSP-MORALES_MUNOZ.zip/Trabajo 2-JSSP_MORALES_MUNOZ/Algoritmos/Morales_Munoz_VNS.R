# Trabajo 2 Optimización en ingeniería

# Nombres:
#         - David Morales P.
#         - Claudio Muñoz M.

# Función para calcular el makespan de una solución
calculate_makespan <- function(times, machines, sequence) {
  num_jobs <- nrow(times)
  num_machines <- ncol(times)
  end_times <- matrix(0, nrow = num_jobs, ncol = num_machines)
  
  for (i in sequence) {
    for (j in 1:num_machines) {
      machine <- machines[i, j]
      prev_end_time <- ifelse(j > 1, end_times[i, j - 1], 0)
      prev_job_end_time <- ifelse(i > 1, end_times[i - 1, j], 0)
      end_times[i, j] <- max(prev_end_time, prev_job_end_time) + times[i, machine]
    }
  }
  
  return(max(end_times[num_jobs, ]))
}

# Función para generar una solución inicial aleatoria
generate_initial_solution <- function(num_jobs, num_machines) {
  sequence <- sample(1:num_jobs)
  return(sequence)
}

# Función para generar una vecindad de soluciones
generate_neighborhood <- function(sequence) {
  num_jobs <- length(sequence)
  neighborhood <- list()
  
  for (i in 1:(num_jobs - 1)) {
    for (j in (i + 1):num_jobs) {
      neighbor <- sequence
      neighbor[c(i, j)] <- sequence[c(j, i)]
      neighborhood[[length(neighborhood) + 1]] <- neighbor
    }
  }
  
  return(neighborhood)
}

# Función para buscar una mejor solución en la vecindad
search_best_neighbor <- function(times, machines, sequence, neighborhood) {
  best_makespan <- calculate_makespan(times, machines, sequence)
  best_neighbor <- sequence
  
  for (neighbor in neighborhood) {
    neighbor_makespan <- calculate_makespan(times, machines, neighbor)
    if (neighbor_makespan < best_makespan) {
      best_makespan <- neighbor_makespan
      best_neighbor <- neighbor
    }
  }
  
  return(list(neighbor = best_neighbor, makespan = best_makespan))
}

# Función para ejecutar el algoritmo VNS
vns <- function(times, machines, max_iterations) {
  num_jobs <- nrow(times)
  num_machines <- ncol(times)
  best_sequence <- generate_initial_solution(num_jobs, num_machines)
  
  best_makespan <- calculate_makespan(times, machines, best_sequence)
  
  current_sequence <- best_sequence
  current_makespan <- best_makespan
  
  iteration <- 0
  
  while (iteration < max_iterations) {
    k_max <- min(num_jobs - 1, 3)
    k <- 1
    
    while (k <= k_max) {
      neighborhood <- generate_neighborhood(current_sequence)
      search_result <- search_best_neighbor(times, machines, current_sequence, neighborhood)
      
      if (search_result$makespan < current_makespan) {
        current_sequence <- search_result$neighbor
        current_makespan <- search_result$makespan
        k <- 1
      } else {
        k <- k + 1
      }
    }
    
    if (current_makespan < best_makespan) {
      best_sequence <- current_sequence
      best_makespan <- current_makespan
    }
    
    iteration <- iteration + 1
  }
  
  # Construir la matriz de tiempos en que se ejecuta cada tarea en una máquina
  schedule <- matrix(0, nrow = num_jobs, ncol = num_machines)
  starts_time <- matrix(0, nrow = num_jobs, ncol = num_machines)
  for (i in best_sequence) {
    for (j in 1:num_machines) {
      machine <- machines[i, j]
      prev_end_time <- ifelse(j > 1, schedule[i, j - 1], 0)
      prev_job_end_time <- ifelse(i > 1, schedule[i - 1, j], 0)
      starts_time[i, j] <- max(prev_end_time, prev_job_end_time)
      schedule[i, j] <- max(prev_end_time, prev_job_end_time) + times[i, machine]
    }
  }
  return(list(sequence = best_sequence, makespan = best_makespan, schedule = schedule, starts = starts_time))
}



# Ejemplo de uso

# Datos de ejemplo
nb_of_jobs <- 15
nb_of_machines <- 15
times <- matrix(c(
  94, 66, 10, 53, 26, 15, 65, 82, 10, 27, 93, 92, 96, 70, 83,
  74, 31, 88, 51, 57, 78,  8,  7, 91, 79, 18, 51, 18, 99, 33,
  4, 82, 40, 86, 50, 54, 21,  6, 54, 68, 82, 20, 39, 35, 68,
  73, 23, 30, 30, 53, 94, 58, 93, 32, 91, 30, 56, 27, 92,  9,
  78, 23, 21, 60, 36, 29, 95, 99, 79, 76, 93, 42, 52, 42, 96,
  29, 61, 88, 70, 16, 31, 65, 83, 78, 26, 50, 87, 62, 14, 30,
  18, 75, 20,  4, 91, 68, 19, 54, 85, 73, 43, 24, 37, 87, 66,
  32, 52,  9, 49, 61, 35, 99, 62,  6, 62,  7, 80,  3, 57,  7,
  85, 30, 96, 91, 13, 87, 82, 83, 78, 56, 85,  8, 66, 88, 15,
  5, 59, 30, 60, 41, 17, 66, 89, 78, 88, 69, 45, 82,  6, 13,
  90, 27,  1,  8, 91, 80, 89, 49, 32, 28, 90, 93,  6, 35, 73,
  47, 43, 75,  8, 51,  3, 84, 34, 28, 60, 69, 45, 67, 58, 87,
  65, 62, 97, 20, 31, 33, 33, 77, 50, 80, 48, 90, 75, 96, 44,
  28, 21, 51, 75, 17, 89, 59, 56, 63, 18, 17, 30, 16,  7, 35,
  57, 16, 42, 34, 37, 26, 68, 73,  5,  8, 12, 87, 83, 20, 97
), nrow = nb_of_jobs, ncol = nb_of_machines)
machines <- matrix(c(
  7, 13,  5,  8,  4,  3, 11, 12,  9, 15, 10, 14,  6,  1,  2,
  5,  6,  8, 15, 14,  9, 12, 10,  7, 11,  1,  4, 13,  2,  3,
  2,  9, 10, 13,  7, 12, 14,  6,  1,  3,  8, 11,  5,  4, 15,
  6,  3, 10,  7, 11,  1, 14,  5,  8, 15, 12,  9, 13,  2,  4,
  8,  9,  7, 11,  5, 10,  3, 15, 13,  6,  2, 14, 12,  1,  4,
  6,  4, 13, 14, 12,  5, 15,  8,  3,  2, 11,  1, 10,  7,  9,
  13,  4,  8,  9, 15,  7,  2, 12,  5,  6,  3, 11,  1, 14, 10,
  12,  6,  1,  8, 13, 14, 15,  2,  3,  9,  5,  4, 10,  7, 11,
  11, 12,  7, 15,  1,  2,  3,  6, 13,  5,  9,  8, 10, 14,  4,
  7, 12, 10,  3,  9,  1, 14,  4, 11,  8,  2, 13, 15,  5,  6,
  5,  8, 14,  1,  6, 13,  7,  9, 15, 11,  4,  2, 12, 10,  3,
  3, 15,  1, 13,  7, 11,  8,  6,  9, 10, 14,  2,  4, 12,  5,
  6,  9, 11,  3,  4,  7, 10,  1, 14,  5,  2, 12, 13,  8, 15,
  9, 15,  5, 14,  6,  7, 10,  2, 13,  8, 12, 11,  4,  3,  1,
  11,  9, 13,  7,  5,  2, 14, 15, 12,  1,  8,  4,  3, 10,  6
), nrow = nb_of_jobs, ncol = nb_of_machines)

# Parámetros del algoritmo
max_iterations <- 10

# Ejecutar el algoritmo VNS
inicio <- Sys.time()
solution <- vns(times, machines, max_iterations)
fin <- Sys.time()
tiempo_total <- fin - inicio

# Imprimir la solución
print(solution$star)
cat("tiempo:", tiempo_total,
"\nmakespan", max(solution$schedule),"\n")




###########################################################################################################################################
###########################################################################################################################################
###########################################################################################################################################


# Crea un vector con los tiempos de término
tiempos_termino <- c(552.75, 3.51, 3.65)  # Se toman los tiempos de término de la primera operación

# Crea un vector con los nombres de los algoritmos
algoritmos <- c("Método exacto", "VNS 1", "VNS 2")

# Crea el gráfico de barras con escala logarítmica en el eje y
barplot(log10(tiempos_termino), names.arg = algoritmos,
        xlab = "Algoritmo", ylab = "Tiempo de Término (escala logarítmica)",
        col = c("blue", "red", "green"), ylim = c(0, ceiling(log10(max(tiempos_termino)))))

# Agrega etiquetas de valor sobre las barras
text(x = barplot(log10(tiempos_termino), names.arg = algoritmos,
                 xlab = "Algoritmo", ylab = "Tiempo de Término (escala logarítmica)",
                 col = c("blue", "red", "green"), ylim = c(0, ceiling(log10(max(tiempos_termino))))),
     y = log10(tiempos_termino), label = tiempos_termino, pos = 3)


# Crea un vector con los tiempos de término
tiempos_termino <- c(2653.25 , 3.63, 3.64)  # Se toman los tiempos de término de la primera operación

# Crea un vector con los nombres de los algoritmos
algoritmos <- c("Método exacto", "VNS 1", "VNS 2")

# Crea el gráfico de barras con escala logarítmica en el eje y
barplot(log10(tiempos_termino), names.arg = algoritmos,
        xlab = "Algoritmo", ylab = "Tiempo de Término (escala logarítmica)",
        col = c("blue", "red", "green"), ylim = c(0, ceiling(log10(max(tiempos_termino)))))

# Agrega etiquetas de valor sobre las barras
text(x = barplot(log10(tiempos_termino), names.arg = algoritmos,
                 xlab = "Algoritmo", ylab = "Tiempo de Término (escala logarítmica)",
                 col = c("blue", "red", "green"), ylim = c(0, ceiling(log10(max(tiempos_termino))))),
     y = log10(tiempos_termino), label = tiempos_termino, pos = 3)


